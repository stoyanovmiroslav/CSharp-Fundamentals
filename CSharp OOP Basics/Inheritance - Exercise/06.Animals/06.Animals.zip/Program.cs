﻿using System;
using System.Collections.Generic;


public class Program
{
    static void Main(string[] args)
    {
        List<Animal> animals = new List<Animal>();
        string input = "";
        while ((input = Console.ReadLine()) != "Beast!")
        {
            try
            {
                string[] animalData = Console.ReadLine().Split();


                switch (input)
                {
                    case "Dog":
                        Dog dog = new Dog(animalData[0], int.Parse(animalData[1]), animalData[2]);
                        AddAnimal(animals, dog);
                        break;
                    case "Cat":
                        Cat cat = new Cat(animalData[0], int.Parse(animalData[1]), animalData[2]);
                        AddAnimal(animals, cat);
                        break;
                    case "Frog":
                        Frog frog = new Frog(animalData[0], int.Parse(animalData[1]), animalData[2]);
                        AddAnimal(animals, frog);
                        break;
                    case "Tomcat":
                        Tomcat tomcat = new Tomcat(animalData[0], int.Parse(animalData[1]));
                        AddAnimal(animals, tomcat);
                        break;
                    case "Kitten":
                        Kitten kitten = new Kitten(animalData[0], int.Parse(animalData[1]));
                        AddAnimal(animals, kitten);
                        break;
                    default: throw new ArgumentException("Invalid input!");
                }
            }
            catch (ArgumentException argEx)
            {
                Console.WriteLine(argEx.Message);
            }
        }
        foreach (var animal in animals)
        {
            Console.WriteLine(animal);
        }
    }

    private static void AddAnimal(List<Animal> animals, Animal animal)
    {
        animals.Add(animal);
    }
}

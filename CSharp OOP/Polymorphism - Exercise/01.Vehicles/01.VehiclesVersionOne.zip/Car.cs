﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles
{
    public class Car : IVehicles
    {
        public Car(string typeOfVehicle, double FuelQuantity, double fuelConsumption)
        {
            this.TypeOfVehicle = typeOfVehicle;
            this.FuelQuantity = FuelQuantity;
            this.FuelConsumption = fuelConsumption + 0.9;
        }
        
        public void Drive(double distance)
        {
            double neededFuel = distance * this.FuelConsumption;

            if (neededFuel <= this.FuelQuantity)
            {
                Console.WriteLine($"Car travelled {distance} km");
                this.FuelQuantity -= neededFuel;
            }
            else
            {
                Console.WriteLine("Car needs refueling");
            }
        }

        public void Refuel(double liters)
        {
            this.FuelQuantity += liters;
        }

        public string TypeOfVehicle { get; private set; }

        public double FuelConsumption { get; private set; }

        public double FuelQuantity { get; private set; }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:f2}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles
{
    public interface IVehicles
    {
        string TypeOfVehicle { get; }
        double FuelConsumption { get; }
        double FuelQuantity { get; }

        void Drive(double distance);
        void Refuel(double distance);
    }
}
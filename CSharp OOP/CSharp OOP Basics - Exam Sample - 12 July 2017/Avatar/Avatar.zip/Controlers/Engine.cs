﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Engine
{
    public void Run()
    {
        NationsBuilder nationsBuilder = new NationsBuilder();

        string input;
        while ((input = Console.ReadLine()) != "Quit")
        {
            List<string> splitInput = input.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).ToList();

            string command = splitInput[0];
            splitInput.RemoveAt(0);

            switch (command)
            {
                case "Bender":
                    nationsBuilder.AssignBender(splitInput);
                    break;
                case "Monument":
                    nationsBuilder.AssignMonument(splitInput);
                    break;
                case "Status":
                    string status = nationsBuilder.GetStatus(splitInput[0]);
                    this.OutputWriter(status);
                    break;
                case "War":
                    nationsBuilder.IssueWar(splitInput[0]);
                    break;
            }
        }
        string record = nationsBuilder.GetWarsRecord();
        this.OutputWriter(record);
    }

    private void OutputWriter(string output)
    {
        Console.WriteLine(output);
    }
}
